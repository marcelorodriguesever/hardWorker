import Tabela from "../components/Tabela";
import useClientes from "../hooks/useClientes";


export default function DadosApi  () {


    const {
        cliente,
        clientes,
        novoCliente,
        salvarCliente,
        selecionarCliente,
        excluirCliente,
        tabelaVisivel,
        exibirTabela
      } = useClientes()







    return (
        
            

            <div className="flex flex-col justify-center items-center w-full h-screen">

                <h1> Dados da Api </h1>

                <div className="flex flex-col justufy-center items-center w-full ">
                <Tabela clientes={clientes}
                  clienteSelecionado={selecionarCliente}
                  clienteExcluido={excluirCliente} />
              </div>

        </div>
    )

}