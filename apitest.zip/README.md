## PARA COMEÇAR

instale as dependencias :

npm install
# ou
yarn install


# PARA EXECUTAR O PROJETO 

npm run dev
# or
yarn run dev


# TECNOLOGIAS UTILIZADAS 
- Next js
- React js
- Tailwind Css
- Dados considos de uma Api do Firebase com base de dados criada para o teste

# FUNCIONALIDADES

- tela inicial com dados exibidos  da api do banco de dados 
opção para criar novo cadastro (botão)
- tela de novo cadastro
opção para alterar dados com (icone)
- tela de alterar dados 
opção de excluir cadastro
